`include "alucodes.sv"
module cpu #( parameter n = 8) // data bus width
	(
	input wire clk,
	input wire reset, // master reset
	input wire loadSwitch,
	input wire [n-1:0] dataSwitch,
	output logic[n-1:0] outport // need an output port, tentatively this will be the ALU output
	);

	// declarations of local signals that connect CPU modules

	// ALU
	wire [2:0] ALUfunc; // ALU function
	wire imm; // immediate operand signal
	wire [n-1:0] AluB, AluA; // output from imm MUX

	// registers
	wire [n-1:0] Rdata1, Rdata2, Rdata3, Wdata, outX2, outY2; // Register data
	wire w; // register write control

	// Program Counter
	parameter Psize = 5; // up to 64 instructions
	wire PCincr; // program counter control
	wire [Psize-1 : 0]ProgAddress;

	// ROM
	parameter Isize = n+4; // Isize - instruction width
	wire [Isize:0] I; // I - instruction code

	// Decoder
	wire dispX2, dispY2, switchControl, wDCR;

	// Port
	wire portStart, portDone, wPRT;

	//------------- code starts here ---------
	// module instantiations
	pc  #(.Psize(Psize))
		PRC0 (
		.clk(clk),
		.reset(reset),
		.PCincr(PCincr),
		.PCout(ProgAddress) );

	ROM #(.Psize(Psize),.Isize(Isize))
		ROM0 (
		.address(ProgAddress),
		.I(I) );

	decoder DCR0 (
		.loadSwitch(loadSwitch),
		.portDone(portDone),
		.opcode(I[Isize:Isize-2]),
		.PCincr(PCincr),
		.ALUfunc(ALUfunc),
		.imm(imm),
		.w(wDCR),
		.switchControl(switchControl),
		.portStart(portStart) );

	port PRT0 (
		.portStart(portStart),
		.loadSwitch(loadSwitch),
		.clk(clk),
		.w(wPRT),
		.portDone(portDone) );

	registers   #(.n(n))
		GPR0 (
		.clk(clk),
		.w(w),
		.Wdata(Wdata),
		.srcAddr1(I[Isize-5:Isize-8]),  // reg %d number
		.srcAddr2(I[Isize-9:0]),
		.dstAddr(I[Isize-3:Isize-4]), // reg %s number
		.srcData1(Rdata1),
		.srcData2(Rdata2),
		.dstData(Rdata3),
		.outX2(outX2),
		.outY2(outY2) );

	alu    #(.n(n))
		ALU0 (
		.a(AluA),
		.b(AluB),
		.func(ALUfunc),
		.result(Wdata) ); // ALU result -> destination reg

	// create MUX for immediate operand
	assign AluB = (switchControl ? dataSwitch : (imm ? I[n-1:0] : Rdata2));

	assign AluA = (imm ? Rdata3 : Rdata1);
	// this will take the lowest 8 bits of the instruction bus i.e. take the second operand as is

	assign w = (switchControl ? wPRT : wDCR);

	assign outport = (loadSwitch ? outY2 : outX2);

endmodule
